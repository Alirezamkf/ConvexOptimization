"""
Copyright 2013 Steven Diamond

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from cvxpy.atoms.affine.wraps import nonneg_wrap, nonpos_wrap
from cvxpy.expressions.variable import Variable
from cvxpy.utilities.bounds import get_expr_bounds_if_supported
from cvxpy.utilities.solver_context import SolverInfo


def maximum_canon(expr, args, solver_context: SolverInfo | None = None):
    shape = expr.shape
    bounds = get_expr_bounds_if_supported(expr, solver_context)
    t = Variable(shape, bounds=bounds)

    # for DNLP we must initialize the new variable (DNLP guarantees that
    # x.value will be set when this function is called)
    if expr.value is not None:
        t.value = expr.value

    if expr.is_nonneg():
        t = nonneg_wrap(t)
    if expr.is_nonpos():
        t = nonpos_wrap(t)

    constraints = [t >= elem for elem in args]

    return t, constraints
