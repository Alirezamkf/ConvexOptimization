"""
Copyright, the CVXPY authors

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import numpy as np
import pytest

import cvxpy as cp
from cvxpy.reductions.solvers.defines import INSTALLED_SOLVERS
from cvxpy.tests.nlp_tests.derivative_checker import DerivativeChecker


@pytest.mark.skipif('IPOPT' not in INSTALLED_SOLVERS, reason='IPOPT is not installed.')
class TestBroadcast():

    def test_scalar_to_matrix(self):
        np.random.seed(0)
        x = cp.Variable(name='x')
        A = np.random.randn(200, 6)
        obj = cp.sum(cp.square(x - A))
        problem = cp.Problem(cp.Minimize(obj))

        x.value = 0.1
        checker = DerivativeChecker(problem)
        checker.run_and_assert()
        x.value = None

        problem.solve(solver=cp.IPOPT, nlp=True, hessian_approximation='exact',
                    derivative_test='none', verbose=True)
        assert(problem.status == cp.OPTIMAL)
        assert(np.allclose(x.value, np.mean(A)))

    def test_row_broadcast(self):
        np.random.seed(0)
        x = cp.Variable(6, name='x')
        A = np.random.randn(5, 6)
        obj = cp.sum(cp.square(x - A))
        problem = cp.Problem(cp.Minimize(obj))

        problem.solve(solver=cp.IPOPT, nlp=True, hessian_approximation='exact',
                    derivative_test='none', verbose=True)
        assert(problem.status == cp.OPTIMAL)
        assert(np.allclose(x.value, np.mean(A, axis=0)))

        checker = DerivativeChecker(problem)
        checker.run_and_assert()


    def test_column_broadcast(self):
        np.random.seed(0)
        x = cp.Variable((5, 1), name='x')
        A = np.random.randn(5, 6)
        obj = cp.sum(cp.square(x - A))
        problem = cp.Problem(cp.Minimize(obj))

        problem.solve(solver=cp.IPOPT, nlp=True, hessian_approximation='exact',
                    derivative_test='none', verbose=True)
        assert(problem.status == cp.OPTIMAL)
        assert(np.allclose(x.value.flatten(), np.mean(A, axis=1)))

        checker = DerivativeChecker(problem)
        checker.run_and_assert()

    def test_subtle_broadcast1(self):
        n = 5
        x = cp.Variable((n, 1))
        b = np.ones(n)
        constraints = [cp.log(x) == b]
        x.value = np.random.rand(n, 1) + 0.1

        prob = cp.Problem(cp.Minimize(0), constraints)
        checker = DerivativeChecker(prob)
        checker.run_and_assert()

    def test_subtle_broadcast2(self):
        n = 5
        x = cp.Variable((n, 1))
        b = np.ones((1, n))
        constraints = [cp.log(x) == b]
        x.value = np.random.rand(n, 1) + 0.1

        prob = cp.Problem(cp.Minimize(0), constraints)
        checker = DerivativeChecker(prob)
        checker.run_and_assert()
